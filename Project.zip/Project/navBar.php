<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="home.php">HA</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="show.php?key=m">Men<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="show.php?key=ms">Shirts</a></li>
                    <li><a href="show.php?key=mt">T-Shirts</a></li>
                    <li><a href="show.php?key=md">Denim</a></li>
                    <li><a href="show.php?key=mf">Footwear</a></li>
                </ul>
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="show.php?key=w">Women<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="show.php?key=ws">Shirts</a></li>
                    <li><a href="show.php?key=wt">T-Shirts</a></li>
                    <li><a href="show.php?key=wd">Denim</a></li>
                    <li><a href="show.php?key=wnd">Non-Denim</a></li>
                    <li><a href="show.php?key=wf">Footwear</a></li>
                </ul>
            </li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php

            if(isset($_SESSION['valid']) && $_SESSION['role']=='user' ) {
                echo "<li><a href=\"logout.php\">Logout</a></li>";
            }
            else{
                echo "<li><a href=\"login.php\">Login</a></li>";
            }

            ?>
        </ul>

        <form class="navbar-form navbar-right" action="home.php" method="get">
            <div class="input-group">
                <input type="text" name="bar" class="form-control" placeholder="Search" >
                <div class="input-group-btn">
                    <button class="btn btn-default" type="submit" >
                        <i class="glyphicon glyphicon-search"></i>
                    </button>
                </div>
            </div>
        </form>


    </div>
</nav>