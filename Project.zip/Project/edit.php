<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
    header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connect.php");

$id = $_GET['id'];
//fetching data in descending order (lastest entry first)
$result = $con->query("SELECT * FROM produtcs  WHERE id=$id");
$r = $result->fetch_assoc();
?>

<html>
<head>
    <title>Edit</title>
    <?php
    include ('BootstrapLinks.php');
    ?>
</head>

<body>
<a href="view.php">Home</a> | <a href="add.php">Add New Product</a> | <a href="logout.php">Logout</a>
<br/><br/>

<form action="addcheck.php?key=edit" method="post" name="form1"  enctype="multipart/form-data">
    <table width="25%" border="0">
        <tr>
            <td>Name</td>
            <td><input type="text" name="name" class="form-control" value="<?php echo $r['name']?>" ></td>
        </tr>
        <tr>
            <td>Quantity</td>
            <td><input type="number" name="qty" class="form-control" value="<?php echo $r['qty']?>" ></td>
        </tr>
        <tr>
            <td>Price</td>
            <td><input type="text" name="price" class="form-control" value="<?php echo $r['price']?>" ></td>
        </tr>
        <tr>
            <td>Category</td>
            <td><input type="text" name="cat" class="form-control" value="<?php echo $r['cat']?>"></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td><input type="text" name="gender" class="form-control" value="<?php echo $r['gender']?>"></td>
        </tr>
        <tr>
            <td>Image</td>
            <td><input type="file" name="fileToUpload" id="fileToUpload"></td>
        </tr>
        <tr>
            <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
            <td><input type="submit" name="Submit" value="Update"></td>
        </tr>
    </table>
</form>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="script.js"></script>

</body>
</html>
