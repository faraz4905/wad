<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])|| $_SESSION['role']!='admin' ) {
    header('Location: login.php');
}
?>

<?php
//including the database connection file
include("connect.php");

//getting id of the data from url
$id = $_GET['id'];

$result = $con->query("SELECT * FROM produtcs WHERE id='$id'")
or die("Could not execute the select query.");

$row = $result->fetch_assoc();

$fname=$row['img'];

unlink('uploads/'.$fname);


//deleting the row from table
if($con->query("DELETE FROM produtcs WHERE id=$id")==true)
//redirecting to the display page (view.php in our case)
    header("Location:view.php");
else
    die("error");
?>

