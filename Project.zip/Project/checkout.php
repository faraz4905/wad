<?php session_start();

if(!isset($_SESSION['valid']) || $_SESSION['role']!='user' ) {

header('Location: login.php');
}

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <title>Home</title>
    <link rel="icon" type="image/png" href="icon/home.png">


    <?php
    include ('BootstrapLinks.php');
    ?>
</head>
<body>

<?php
include ('navBar.php');
?>

<script>
    localStorage.removeItem("cart_array");
</script>

<h3>Thanks for Shopping!</h3>
<p>You will get your delivery with in 4-5 working days. :)</p>



<?php
include ('footer.php');
?>


</body>
</html>
