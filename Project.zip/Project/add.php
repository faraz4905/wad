<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<html>
<head>
    <?php
    if(!isset($_SESSION['valid']) || $_SESSION['role']!='admin') {
        header('Location: login.php');
    }
    ?>


    <title>Add Data</title>

    <?php
    include ('BootstrapLinks.php');
    ?>

</head>

<body>
<a href="view.php">Home</a> | <a href="logout.php">Logout</a>
<br/><br/>

<div class="container">

    <div class="row">

        <div class="col-sm-12">

            <form action="addcheck.php?key=new" method="post" name="form1"  enctype="multipart/form-data">
                <table width="25%" border="0">
                    <tr>
                        <td>Name</td>
                        <td><input type="text" class="form-control" name="name"  ></td>
                    </tr>
                    <tr>
                        <td>Quantity</td>
                        <td><input type="number" name="qty" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Price</td>
                        <td><input type="text" name="price" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Category</td>
                        <td><input type="text" name="cat" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td><input type="text" name="gender" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Image</td>
                        <td><input type="file" name="fileToUpload" id="fileToUpload" ></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="Submit" value="Add"></td>
                    </tr>
                </table>
            </form>


        </div>
    </div>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="script.js"></script>

</body>
</html>

