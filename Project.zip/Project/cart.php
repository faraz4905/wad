<!DOCTYPE html>
<html lang="en">
<head>

    <title>Cart</title>

    <?php
    include ('BootstrapLinks.php');
    ?>

</head>
<body>

<?php
include ('navBar.php');
?>

<?php
include("connect.php");
?>

<p id="show"></p>

<hr>

<p id="totalbill" style="margin-left: 800px;font-size: larger"></p>

<a id="checkout" href="checkout.php" class='btn btn-primary' style="margin-left: 800px;display: none;width: fit-content">Checkout</a>


<script>


    var cart=localStorage.getItem("cart_array");
    var cart_obj;
    if(cart==null)
    {
        document.getElementById("show").innerHTML = "Cart is Empty";
    }
    else {

        var txt="";
        var total=0;
        cart_obj=JSON.parse(cart);
        txt +="<div class='table-responsive'>";
        txt +="<table class=\"table table-light\">";
        txt +="<tr>\n" +
            "        <th>Name</th>\n" +
            "        <th>Quantity</th>\n" +
            "        <th>Price (Rs)</th>\n" +
            "        <th>Image</th>\n" +
            "        <th>Total</th>\n" +
            "        <th>Action</th>\n" +
            "   </tr>";

        for (var i=0;i<cart_obj.length;i++)
        {
            total=total+(cart_obj[i].qty*cart_obj[i].price);
            txt +="<tr><td>"+cart_obj[i].name+"</td><td>"+cart_obj[i].qty+"</td><td>"+cart_obj[i].price+"</td><td><img class=\"img-thumbnail\" width='100' height='100' src=\"uploads/"+cart_obj[i].img+" \"></td><td>"+cart_obj[i].qty*cart_obj[i].price+"</td><td>" +
                "<a class='btn btn-danger' href=\"deleteCart.php?id="+cart_obj[i].id+"\" \n" +
                "onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td></tr>";

        }

        txt +="</table>";
        txt +="</div>";
        document.getElementById("show").innerHTML = txt;
        document.getElementById("totalbill").innerHTML ="Total Bill = " +total;
        document.getElementById('checkout').style.display = 'block';

    }





</script>





<?php
include ('footer.php');
?>

</body>
</html>