<?php

$databaseHost = 'localhost';
$databaseName = 'mydb';
$databaseUsername = 'root';
$databasePassword = '';

$con = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>