<?php
include_once("connect.php");
$result = null;
if(isset($_REQUEST['p'])){
    $name = $_GET['p'];
    $q = "SELECT * FROM produtcs WHERE name LIKE '%$name%' ORDER BY id DESC";
    $result = $con->query($q);
}
else {
    $result = $con->query("SELECT * FROM produtcs ORDER BY id DESC");
}
if($result !== null && $result->num_rows > 0) {
    while ($r = $result->fetch_assoc()) {
        $imageURL = 'uploads/' . rawurlencode($r["img"]);
        ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">

                <a href="#"><img class="card-img-top" src="<?php echo $imageURL; ?>" alt="" style="height: 200px" ></a>
                <div class="card-body">
                    <h4 class="card-title">
                        <a href="#"><?php echo $r['name']; ?></a>
                    </h4>
                    <h5><?php echo $r['price']; ?></h5>
                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam
                        aspernatur!</p>
                </div>
                <div class="card-footer">
                    <button class="btn btn-warning">Buy Now</button>
                </div>

            </div>
        </div>

        <?php
    }
}
else {
    echo "<div class=\"alert alert-danger\" role=\"alert\">
            No Products found !
        </div>";
}
?>