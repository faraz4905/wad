<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>




    <?php
    //including the database connection file
    include_once("connect.php");

    $key=$_GET['key'];

    if(isset($_GET['bar'])) {
        $name = $_GET['bar'];
        if($name!=""){

            if($key=='m')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='ms')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='shirt' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='mt')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='T-shirt' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='md')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='denim' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='mf')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='footwear' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='w')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='ws')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='shirt' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='wt')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='T-shirt' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='wd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='denim' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='wnd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='non-denim' and name LIKE '%$name%' ORDER BY id DESC");
            else if($key=='wf')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='footwear' and name LIKE '%$name%' ORDER BY id DESC");


        }

        else {
            if($key=='m')
                $result = $con->query("SELECT * FROM produtcs where gender='m' ORDER BY id DESC");
            else if($key=='ms')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='shirt' ORDER BY id DESC");
            else if($key=='mt')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='T-shirt' ORDER BY id DESC");
            else if($key=='md')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='denim' ORDER BY id DESC");
            else if($key=='mf')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='footwear' ORDER BY id DESC");
            else if($key=='w')
                $result = $con->query("SELECT * FROM produtcs where gender='f' ORDER BY id DESC");
            else if($key=='ws')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='shirt' ORDER BY id DESC");
            else if($key=='wt')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='T-shirt' ORDER BY id DESC");
            else if($key=='wd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='denim' ORDER BY id DESC");
            else if($key=='wnd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='non-denim' ORDER BY id DESC");
            else if($key=='wf')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='footwear' ORDER BY id DESC");
        }

    }

    else if(isset($_GET['num']))
    {
        $pri=$_GET['num'];

        if($pri==1)
        {

            if($key=='m')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='ms')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='shirt' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='mt')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='T-shirt' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='md')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='denim' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='mf')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='footwear' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='w')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='ws')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='shirt' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='wt')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='T-shirt' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='wd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='denim' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='wnd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='non-denim' and price>='500' and price<'1000' ORDER BY id DESC");
            else if($key=='wf')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='footwear' and price>='500' and price<'1000' ORDER BY id DESC");

        }
        else if($pri==2)
        {
            if($key=='m')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='ms')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='shirt' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='mt')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='T-shirt' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='md')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='denim' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='mf')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='footwear' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='w')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='ws')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='shirt' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='wt')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='T-shirt' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='wd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='denim' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='wnd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='non-denim' and price>='1000' and price<'2000' ORDER BY id DESC");
            else if($key=='wf')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='footwear' and price>='1000' and price<'2000' ORDER BY id DESC");

        }

        else if ($pri==3)
        {
            if($key=='m')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='ms')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='shirt' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='mt')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='T-shirt' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='md')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='denim' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='mf')
                $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='footwear' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='w')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='ws')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='shirt' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='wt')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='T-shirt' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='wd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='denim' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='wnd')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='non-denim' and price>='2000' and price<='3000' ORDER BY id DESC");
            else if($key=='wf')
                $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='footwear' and price>='2000' and price<='3000' ORDER BY id DESC");

        }


    }

    else{

        if($key=='m')
            $result = $con->query("SELECT * FROM produtcs where gender='m' ORDER BY id DESC");
        else if($key=='ms')
            $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='shirt' ORDER BY id DESC");
        else if($key=='mt')
            $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='T-shirt' ORDER BY id DESC");
        else if($key=='md')
            $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='denim' ORDER BY id DESC");
        else if($key=='mf')
            $result = $con->query("SELECT * FROM produtcs where gender='m' and cat='footwear' ORDER BY id DESC");
        else if($key=='w')
            $result = $con->query("SELECT * FROM produtcs where gender='f' ORDER BY id DESC");
        else if($key=='ws')
            $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='shirt' ORDER BY id DESC");
        else if($key=='wt')
            $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='T-shirt' ORDER BY id DESC");
        else if($key=='wd')
            $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='denim' ORDER BY id DESC");
        else if($key=='wnd')
            $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='non-denim' ORDER BY id DESC");
        else if($key=='wf')
            $result = $con->query("SELECT * FROM produtcs where gender='f' and cat='footwear' ORDER BY id DESC");

    }



    ?>
    <?php


        if($key=='m')
            echo "<title>Men</title>";
        else if($key=='ms')
            echo "<title>Men's Shirts</title>";
        else if($key=='mt')
            echo "<title>Men's T-Shirts</title>";
        else if($key=='md')
            echo "<title>Men's Denim</title>";
        else if($key=='mf')
            echo "<title>Men's Footwear</title>";
        else if($key=='w')
            echo "<title>Women</title>";
        else if($key=='ws')
            echo "<title>Women's Shirts</title>";
        else if($key=='wt')
            echo "<title>Women's T-Shirts</title>";
        else if($key=='wd')
            echo "<title>Women's Denim</title>";
        else if($key=='wnd')
            echo "<title>Women's Non-Denim</title>";
        else if($key=='wf')
            echo "<title>Women's FootWear</title>";

        if($key=='m' || $key=='ms' || $key=='mt' || $key=='md' || $key=='mf')
            echo "<link rel=\"icon\" type=\"image/png\" href=\"icon/men.png\">";
        else
            echo "<link rel=\"icon\" type=\"image/png\" href=\"icon/girl.png\">";

    ?>

    <?php
    include ('BootstrapLinks.php');
    ?>

</head>
<body>

<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="home.php">HA</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="show.php?key=m">Men<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="show.php?key=ms">Shirts</a></li>
                    <li><a href="show.php?key=mt">T-Shirts</a></li>
                    <li><a href="show.php?key=md">Denim</a></li>
                    <li><a href="show.php?key=mf">Footwear</a></li>
                </ul>
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="show.php?key=w">Women<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="show.php?key=ws">Shirts</a></li>
                    <li><a href="show.php?key=wt">T-Shirts</a></li>
                    <li><a href="show.php?key=wd">Denim</a></li>
                    <li><a href="show.php?key=wnd">Non-Denim</a></li>
                    <li><a href="show.php?key=wf">Footwear</a></li>
                </ul>
            </li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php

            if(isset($_SESSION['valid'])) {
                echo "<li><a href=\"logout.php\">Logout</a></li>";
            }
            else{
                echo "<li><a href=\"login.php\">Login</a></li>";
            }

            ?>
        </ul>

        <form class="navbar-form navbar-right" action="show.php" method="get">
            <div class="input-group">
                <input type="text" name="bar" class="form-control" placeholder="Search" >
                <input type="hidden" name="key" value=<?php echo $key;?>>
                <div class="input-group-btn">
                    <button class="btn btn-default" type="submit" >
                        <i class="glyphicon glyphicon-search"></i>
                    </button>
                </div>
            </div>
        </form>


    </div>
</nav>

<hr>
<a id="showcart" style="float: right" href="cart.php"></a>
<br><hr>
<script>

    var cart=localStorage.getItem("cart_array");
    if(cart==null)
    {
        document.getElementById("showcart").innerHTML = "Cart(0)";
    }
    else {
        var cart_obj=JSON.parse(cart);
        document.getElementById("showcart").innerHTML = "Cart("+cart_obj.length+")";
    }


</script>

<?php

if($key=='m')
    echo "<h1 style=\"text-align: center;\">Men</h1>";
else if($key=='ms')
    echo "<h1 style=\"text-align: center;\">Men's Shirts</h1>";
else if($key=='mt')
    echo "<h1 style=\"text-align: center;\">Men's T-Shirts</h1>";
else if($key=='md')
    echo "<h1 style=\"text-align: center;\">Men's Denim</h1>";
else if($key=='mf')
    echo "<h1 style=\"text-align: center;\">Men's FootWear</h1>";
else if($key=='w')
    echo "<h1 style=\"text-align: center;\">Women</h1>";
else if($key=='ws')
    echo "<h1 style=\"text-align: center;\">Women's Shirts</h1>";
else if($key=='wt')
    echo "<h1 style=\"text-align: center;\">Women's T-Shirts</h1>";
else if($key=='wd')
    echo "<h1 style=\"text-align: center;\">Women's Denim</h1>";
else if($key=='wnd')
    echo "<h1 style=\"text-align: center;\">Women's Non-Denim</h1>";
else if($key=='wf')
    echo "<h1 style=\"text-align: center;\">Women's FootWear</h1>";

?>
<br>

<!-- Page Content -->
<div class="container">

    <div class="row">

        <div class="col-lg-3">

            <div id="toHide">

                <?php

                if($key=='m' || $key=='ms' || $key=='mt' || $key=='md' || $key=='mf')
                {
                    echo "<a href='show.php?key=m'><h3 class='my-4'>Men</h3></a>";
                    echo "<div class='list-group'>";
                    echo "<a href='show.php?key=ms' class='list-group-item'>Shirts</a>";
                    echo "<a href='show.php?key=mt' class='list-group-item'>T-Shirts</a>";
                    echo "<a href='show.php?key=md' class='list-group-item'>Denim</a>";
                    echo "<a href='show.php?key=mf' class='list-group-item'>Footwear</a>";
                    echo "</div>";
                }

                else
                {
                    echo "<a href='show.php?key=w'><h3 class='my-4'>Women</h3></a>";
                    echo "<div class='list-group'>";
                    echo "<a href='show.php?key=ws' class='list-group-item'>Shirts</a>";
                    echo "<a href='show.php?key=wt' class='list-group-item'>T-Shirts</a>";
                    echo "<a href='show.php?key=wd' class='list-group-item'>Denim</a>";
                    echo "<a href='show.php?key=wnd' class='list-group-item'>Non-Denim</a>";
                    echo "<a href='show.php?key=wf' class='list-group-item'>Footwear</a>";
                    echo "</div>";

                }

                ?>
                <hr>
                <h3 class="my-4">Price</h3>
                <div class="list-group">
                    <a href="show.php?key=<?php echo$key?>&num=1" class="list-group-item">500-1000</a>
                    <a href="show.php?key=<?php echo$key?>&num=2" class="list-group-item">1000-2000</a>
                    <a href="show.php?key=<?php echo$key?>&num=3" class="list-group-item">2000-3000</a>
                </div>


            </div>

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <div class="item active">
                        <img src="imges/abc3.jpg" alt="Los Angeles" style="width:100%;">
                    </div>

                    <div class="item">
                        <img src="imges/abc4.jpg" alt="Chicago" style="width:100%;">
                    </div>


                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <br>

            <div class="row" id="products">
                <?php
                if($result !== null && $result->num_rows > 0) {
                    while ($r = $result->fetch_assoc()) {
                        $imageURL = 'uploads/' . rawurlencode($r["img"]);
                        ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card h-100">

                                <a href="viewProduct.php?id=<?php echo $r['id']?>"><img class="card-img-top" src="<?php echo $imageURL; ?>" alt="" ></a>
                                <div class="card-body">
                                    <h4 class="card-title">
                                        <a href="viewProduct.php?id=<?php echo $r['id']?>"><?php echo $r['name']; ?></a>
                                    </h4>
                                    <h5><?php echo $r['price']; ?></h5>
                                    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam
                                        aspernatur!</p>
                                </div>
                                <div class="card-footer">
                                    <form method="post" action="addToCart.php">
                                        <input type="hidden" name="id" value="<?php echo $r['id'];?>">
                                        <input type="hidden" name="name" value="<?php echo $r['name'];?>">
                                        <input type="hidden" name="price" value="<?php echo $r['price'];?>">
                                        <input type="hidden" name="img" value="<?php echo $r['img'];?>">
                                        <input type="hidden" name="link" value="<?php echo $key;?>">
                                        <input type="text" name="qnt" style="width: 50px" value="1">
                                        <button class="btn btn-warning" type="submit" name="submit" value="submit">Buy Now</button>
                                    </form>
                                </div>

                            </div>
                        </div>

                        <?php
                    }
                }
                else {
                    echo "<div class=\"alert alert-danger\" role=\"alert\">
                     No Products found !
                     </div>";
                }
                ?>


            </div>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->





<?php
include ('footer.php');
?>

</body>
</html>