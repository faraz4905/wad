<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>

<?php
//including the database connection file
include_once("connect.php");

?>
    <title>Home</title>
    <link rel="icon" type="image/png" href="icon/home.png">


    <?php
    include ('BootstrapLinks.php');
    ?>

</head>
<body>

<?php
include ('navBar.php');
?>
<hr>
<a id="showcart" style="float: right" href="cart.php"></a>
<br><hr>
<script>

    var cart=localStorage.getItem("cart_array");
    if(cart==null)
    {
        document.getElementById("showcart").innerHTML = "Cart(0)";
    }
    else {
        var cart_obj=JSON.parse(cart);
        document.getElementById("showcart").innerHTML = "Cart("+cart_obj.length+")";
    }


</script>


<?php
$id = $_GET['id'];

$result = $con->query("SELECT * FROM produtcs WHERE id='$id'")
or die("Could not execute the select query.");

$row = $result->fetch_assoc();

?>


<img src="uploads/<?php echo $row['img'] ;?>" style="">
<h4>Name : <?php echo $row['name'];?></h4>
<h4>Price : <?php echo $row['price'];?></h4>
<h4>Quantity : <?php echo $row['qty'];?></h4>
<form method="post" action="addToCart.php">
    <input type="hidden" name="id" value="<?php echo $row['id'];?>">
    <input type="hidden" name="name" value="<?php echo $row['name'];?>">
    <input type="hidden" name="price" value="<?php echo $row['price'];?>">
    <input type="hidden" name="img" value="<?php echo $row['img'];?>">
    <input type="hidden" name="link" value="viewp">
    <input type="text" name="qnt" style="width: 50px" value="1">
    <button class="btn btn-warning" type="submit" name="submit" value="submit">Buy Now</button>
</form>

<?php
include ('footer.php');
?>


</body>
</html>