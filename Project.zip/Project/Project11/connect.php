<?php

$databaseHost = 'localhost';
$databaseName = 'wad_project';
$databaseUsername = 'root';
$databasePassword = '';

$con = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>