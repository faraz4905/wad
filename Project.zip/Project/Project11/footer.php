<!-- Footer -->
<footer style="background-color: black; height: 150px">
    <div class=\"container\">
        <div class=\"row\">

            <div class=\"col-md-3\">

                <?php

                echo "<h3 style='color: white' >Admin</h3>";


                if(isset($_SESSION['valid']) && $_SESSION['role']=='admin' ) {

                   echo "<a href='logout.php'><p>Logout</p></a>";
                }
                else
                    {
                        echo "<a href='login.php'><p>Login</p></a>";
                    }

                ?>
            </div>
            <div class="col-md-6">

                <?php
                echo "<p style='text-align: right' >Copyright &copy; 1999-" . date("Y") . " by <i> Hisham & Rafy</i></p>";
                ?>

            </div>

            <div class=\"col-md-3\" style="float: right;margin-right: 10px">

                <?php

                echo "<a href=\"https://www.facebook.com/outfitterspk/\" target=\"_blank\"><i class=\"fa fa-facebook\" style=\"font-size:30px;
                      color:blue\"></i></a>
                      <a href=\"https://www.instagram.com/outfitters_pk/\" target=\"_blank\"><i class=\"fa fa-instagram\" style=\"font-size:30px;
                      color:orangered\"></i></a>
                      <a href=\"https://www.snapchat.com/add/outfitters_pk\" target=\"_blank\"><i class=\"fa fa-snapchat\" style=\"font-size:30px;
                      color:yellow\"></i></a>
                      <a href=\"https://twitter.com/OutfittersPak\" target=\"_blank\"><i class=\"fa fa-twitter\" style=\"font-size:30px;
                      color:deepskyblue\"></i></a>
                      <a href=\"https://www.youtube.com/channel/UCP1DcFxwdd_Amyqz3N9lQlQ\" target=\"_blank\"><i class=\"fa fa-youtube\" style=\"font-size:30px;
                      color:darkred\"></i></a>"

                ?>


        </div>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="script.js"></script>