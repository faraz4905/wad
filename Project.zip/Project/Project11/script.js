function isUsernameAvailable(str){
    if (str.length == 0) {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();

        xmlhttp.onreadystatechange = function() {
            console.log(this);
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }

        };
        xmlhttp.open("GET", "checkUsername.php?q=" + str);
        xmlhttp.send();
    }
}

function filterProducts(str){
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("products").innerHTML = this.responseText;
        }

    };
    if(str.length > 0)
        xmlhttp.open("GET", "searchProducts.php?p=" + str);
    else
        xmlhttp.open("GET", "searchProducts.php");
    xmlhttp.send();
}

