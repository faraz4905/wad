<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid']) || $_SESSION['role']!='admin' ) {
    header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connect.php");

//fetching data in descending order (lastest entry first)
$result = $con->query("SELECT * FROM produtcs  ORDER BY id DESC");
?>

<html>
<head>
    <title>Homepage</title>
    <?php
    include ('BootstrapLinks.php');
    ?>
</head>

<body>
<a href="view.php">Home</a> | <a href="add.php">Add New Product</a> | <a href="logout.php">Logout</a>
<br/><br/>

<div class="table-responsive" >

<table class="table table-light">
    <tr>
        <th>Name</th>
        <th>Quantity</th>
        <th>Price (Rs)</th>
        <th>Category</th>
        <th>Gender</th>
        <th>Image</th>
        <th>Actions</th>
    </tr>
    <?php
    while($r = $result->fetch_assoc()) {
        $imageURL = 'uploads/'.rawurlencode($r["img"]);
        echo "<tr>";
        echo "<td>".$r['name']."</td>";
        echo "<td>".$r['qty']."</td>";
        echo "<td>".$r['price']."</td>";
        echo "<td>".$r['cat']."</td>";
        echo "<td>".$r['gender']."</td>";
        echo "<td><a target='_blank' href=".$imageURL.">
			<img class=\"img-thumbnail\" width='100' height='100' src=".$imageURL."></a> </td>";
        echo "<td><a class='btn btn-primary' href=\"edit.php?id=$r[id]\">Edit</a>
                    <a class='btn btn-danger' href=\"delete.php?id=$r[id]\" 
                    onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
    }
    ?>
</table>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="script.js"></script>

</body>
</html>
