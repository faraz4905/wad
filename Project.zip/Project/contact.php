<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact</title>
    <link rel="icon" type="image/png" href="icon/contact.png">


    <?php
    include ('BootstrapLinks.php');
    ?>



</head>
<body>

<?php
include ('navBar.php');
?>

<?php

$name=$email=$phone=$msg="";
$emailErr=$nameErr=$phoneErr=$msgErr="";
$check=0;

if ($_SERVER["REQUEST_METHOD"] == "POST"){

    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
        if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
            $nameErr = "Only letters and white space allowed";
        }
    }

    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    if (empty($_POST["phone"])) {
        $phoneErr = "Phone is required";
    } else {
        $phone = $_POST["phone"];
        if (!preg_match("/^03\d{2}-\d{7}$/",$phone)) {
            $phoneErr = "Invalid phone Number e.g 03xx-xxxxxxx";
        }
    }

    if(empty($_POST["msg"]))
    {
        $msgErr="can not be empty";
    }
    else
        $msg=$_POST["msg"];

    if($nameErr=="" && $emailErr=="" && $phoneErr=="" && $msgErr=="")
        $check=1;

}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if($check==1)
{
    echo "Your Message has been received<br>We Will Contact you as soon as posible <br>Thank You! ";
}

else {
    ?>

    <h3 style="text-align:center">Contact Us</h3>

    <div class="container-fluid">

        <div class="row" style="margin-top: 40px">

            <div class="col-xs-12 col-md-6 col-sm-12" style="clear:right;">

                <form method="post" novalidate action="contact.php">


                    Name:<span class="error">*</span> <input type="text" name="name" class="form-control"
                                                             value="<?php echo $name; ?>">
                    <span class="error"><?php echo $nameErr; ?></span>
                    <br><br>
                    Email:<span class="error">*</span> <input type="email" name="email" class="form-control"
                                                              value="<?php echo $email; ?>">
                    <span class="error"><?php echo $emailErr; ?></span>
                    <br><br>
                    phone:<span class="error">*</span> <input type="text" name="phone" class="form-control"
                                                              value="<?php echo $phone; ?>">
                    <span class="error"><?php echo $phoneErr; ?></span>
                    <br><br>
                    Message:<span class="error">*</span> <input type="text" name="msg" class="form-control"
                                                                style="height: 200px;" value="<?php echo $msg; ?>">
                    <span class="error"><?php echo $msgErr; ?></span>
                    <br><br>
                    <input class='btn btn-primary' type="submit" name="submit" value="Submit">
                    <br><br>

                </form>

            </div>

            <div class="col-xs-12 col-md-6 col-sm-12" style="border:2px solid crimson;clear: left">


                For questions about your orders, please include your order<br>
                number,your name and your city name<br><br>

                Email:
                contactus@outfitters.com.pk<br><br>

                Telephone: 042-35467243<br><br>

                042-35467274<br><br>

                For any kind of exchange, complaint or service query,<br>
                please contact us at<br><br>

                Email:
                support@outfitters.com.pk<br><br>

                Telephone: 042-35467274<br><br>

                General Queries:
                Info1@outfitters.com.pk


            </div>

        </div>
    </div>


    <br>
    <br>

    <div class="col-md-12 col-sm-12">

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d108773.
84259224204!2d74.22492564204286!3d31.574040671377706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.
1!3m3!1m2!1s0x3919044dc1429359%3A0x24c826738d9c415f!2sOutfitters!5e0!3m2!1sen!2s!4v1523707939415"
                width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

    </div>


    <?php
}
?>

<?php
include ('footer.php');
?>

</body>
</html>