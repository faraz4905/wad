<!DOCTYPE html>
<html lang="en">
<head>

    <title>Home</title>
    <link rel="icon" type="image/png" href="icon/home.png">


    <?php
    include ('BootstrapLinks.php');
    ?>

</head>
<body>

<?php
include ('navBar.php');
?>

<?php
include("connect.php");

if(isset($_POST['submit'])) {

    $id=$_POST['id'];
    $name=$_POST['name'];
    $price=$_POST['price'];
    $img=$_POST['img'];
    $qnt=$_POST['qnt'];
    $link=$_POST['link'];
    $count=0;

    ?>
    <p id="cname" style="display: none"><?php echo $name;?></p>
    <p id="cprice" style="display: none"><?php echo $price;?></p>
    <p id="cimg" style="display: none"><?php echo $img;?></p>
<?php
    $result = $con->query("SELECT * FROM produtcs WHERE id='$id'")
    or die("Could not execute the select query.");

    $row = $result->fetch_assoc();



    if($qnt<=0 || $qnt>$row['qty'])
    {
        echo "only "; echo $row['qty']; echo " products available";
        echo "<br>";
        if($link=="home" || $link=="viewp")
            echo "<a href='home.php'>Go back</a>";
        else
            echo "<a href='show.php?key=$link'>Go back</a>";
    }
    else
    {
        $count=1;
        ?>

        <script>

            var cart_array = null;
            if(localStorage.getItem('cart_array')==null)
                cart_array = new Array();
            else
                cart_array = JSON.parse(localStorage.getItem("cart_array"));

            var cart_obj = {
                id:<?php echo $id;?>,
                qty:<?php echo $qnt; ?>,
                name: document.getElementById("cname").innerHTML,
                price: document.getElementById("cprice").innerHTML,
                img: document.getElementById("cimg").innerHTML
            }

            cart_array.push(cart_obj);

            localStorage.setItem('cart_array', JSON.stringify(cart_array));

        </script>


<?php
    }
}

if($count==1 && ($link=='home' || $link=="veiwp"))
{
    echo "Your product has been added to the cart<br>";
    echo "<a href='cart.php'>Go to cart</a><br>";
    echo "<a href='home.php'>Go back</a><br>";
}
else if($count==1 && $link!='home'){


    echo "Your product has been added to the cart<br>";
    echo "<a href='cart.php'>Go to cart</a><br>";
    echo "<a href='show.php?key=$link'>Go back</a><br>";

}

?>





<?php
include ('footer.php');
?>



</body>
</html>