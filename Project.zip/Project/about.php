<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>About</title>
    <link rel="icon" type="image/png" href="icon/about.png">


    <?php
    include ('BootstrapLinks.php');
    ?>




</head>
<body>

<?php
include ('navBar.php');
?>



<h2 style="text-align: center;">About Us</h2>
<br><br>

<div class="container-fluid">

    <div class="row">
        <div class="col-md-6 col-sm-12">

            <h2>Who Are we?</h2>
            <p>Outfitters is a name which is synonymous with fashions & trends in Pakistan.<br>
                Established in 2003, this is a company birthed out of an ambitious investment<br>
                in the fashion industry by the visionary team. Pioneers of providing the latest<br>
                fashion apparel to the Pakistani consumers.<br></p><br>

            <h2>Why are we doing this?</h2>
            <p>
                Outfitters has been at the forefront of introducing the latest and trendiest clothes<br>
                for the masses. With the immense love and support of the loyal customers over the last<br>
                13 years, Outfitters has been able to expand into further brands with 60+ stores throughout Pakistan.<br>
            </p><br>

            <h2>What makes us different?</h2>
            <p>
                Outfitters started out as trendy street-smart fashion for men and women. In 2008, Outfitters
                introduced a brand for kids, as Outfitters Junior, focusing on kids’ fashion.
                The company is steadily growing and now has set foot in the international market,
                with aims to elevate the brand into a truly global player.
            </p><br>
        </div>

        <div class="col-md-6 col-sm-12">
            <img src="imges/abc6.jpg" style="height: 500px;">

        </div>


    </div>
</div>






<?php
include ('footer.php');
?>

</body>
</html>