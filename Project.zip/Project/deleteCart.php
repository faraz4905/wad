<!DOCTYPE html>
<html lang="en">
<head>

    <title>Cart</title>

    <?php
    include ('BootstrapLinks.php');
    ?>

</head>
<body>

<?php
include ('navBar.php');
?>

<?php

$id=$_GET['id'];

?>

<p id="todel" style="display: none"><?php echo $id ?></p>


<script>

    var i=0;
    var cart=localStorage.getItem("cart_array");
    var cart_obj=JSON.parse(cart);
    var cart_array = new Array();

    for (i=0;i<cart_obj.length;i++)
    {

        if(cart_obj[i].id!=document.getElementById("todel").innerHTML)
        {
            cart_array.push(cart_obj[i]);
        }

    }

    localStorage.setItem('cart_array', JSON.stringify(cart_array));

    cart=localStorage.getItem("cart_array");
    cart_obj=JSON.parse(cart);

    if(cart_obj.length==0)
    {
        localStorage.removeItem("cart_array");
    }

</script>


<h3>Your product is been removed</h3>
<a href="cart.php">Go back</a>


<?php
include ('footer.php');
?>



</body>
</html>






