-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2019 at 11:20 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders_nonuser`
--

CREATE TABLE `orders_nonuser` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `produtcs`
--

CREATE TABLE `produtcs` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` double NOT NULL,
  `cat` varchar(50) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `img` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produtcs`
--

INSERT INTO `produtcs` (`id`, `name`, `qty`, `price`, `cat`, `gender`, `img`) VALUES
(3, 'shirt1', 4, 2000, 'shirt', 'm', 'abc3_1545145379.jpg'),
(5, 'T-shirt1', 2, 1000, 'T-shirt', 'm', 'abc6_1545145344.jpg'),
(7, 'denim1', 8, 2500, 'denim', 'm', 'abc3_1545145318.jpg'),
(9, 'footwear1', 9, 2000, 'footwear', 'm', 'abc4_1545145296.jpg'),
(12, 'shirt2', 5, 2000, 'shirt', 'f', 'abc6_1545145264.jpg'),
(14, 'T-shirt2', 6, 1500, 'T-shirt', 'f', 'abc3_1545145238.jpg'),
(16, 'footwear2', 9, 2500, 'footwear', 'f', 'abc4_1545145213.jpg'),
(18, 'non-denim2', 2, 1300, 'non-denim', 'f', 'abc6_1545145200.jpg'),
(19, 'denim1', 3, 2000, 'denim', 'f', 'abc4_1545145187.jpg'),
(20, 'denim2', 8, 3000, 'denim', 'f', 'abc3_1545145174.jpg'),
(21, 'urdu', 12, 1111, 'Demon', '8', 'abc4_1545208472.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `visa` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `cnic` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `username`, `pass`, `visa`, `address`, `phone`, `cnic`, `role`) VALUES
(9, 'faraz', 'faraz@gmail.com', 'faraz', 'faraz123', '1234567891234567', 'asddd', '0333-1234567', '3520218350841', 'user'),
(11, 'admin', 'admin@gmail.com', 'admin', 'admin', '1234567891234567', 'Lahore', '0333-1234567', '3520218350841', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_nonuser`
--
ALTER TABLE `orders_nonuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produtcs`
--
ALTER TABLE `produtcs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders_nonuser`
--
ALTER TABLE `orders_nonuser`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `produtcs`
--
ALTER TABLE `produtcs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
